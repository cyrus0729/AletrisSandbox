local sampleEntity = {
    name = "AletrisSandbox/CustomTimingOshiro",
    depth = -12500,
    texture = "characters/oshiro/boss13",
    placements = {
        {
            name = "CustomTimingOshiro",
            data = {
                timings = ""
            },
        },
    },
}

return sampleEntity