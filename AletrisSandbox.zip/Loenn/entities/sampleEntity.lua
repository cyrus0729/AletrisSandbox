local sampleEntity = {
    name = "AletrisSandbox/SampleEntity",
    depth = -8500,
    texture = "objects/AletrisSandbox/sampleEntity/idle00",
    placements = {
        {
            name = "normal",
            data = {
                sampleProperty = 0,
            },
        },
    },
}

return sampleEntity