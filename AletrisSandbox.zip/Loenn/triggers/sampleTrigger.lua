local sampleTrigger = {
    name = "AletrisSandbox/SampleTrigger",
    placements = {
        {
            name = "normal",
            data = {
                width = 8,
                height = 8,
                sampleProperty = 0,
            },
        },
    },
}

return sampleTrigger