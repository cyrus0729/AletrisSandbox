local IWBTGJumpTrigger = {
    name = "AletrisSandbox/IWBTGJumpTrigger",
    placements = {
        {
            name = "IWBTG Jump Physics Trigger",
            data = {
                width = 8,
                height = 8,
                Enable = true
            },
        },
    },
}

return IWBTGJumpTrigger