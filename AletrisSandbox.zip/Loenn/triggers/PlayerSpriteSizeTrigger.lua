local PlayerSpriteSizeTrigger = {
    name = "AletrisSandbox/PlayerSpriteSizeTrigger",
    placements = {
        {
            name = "Player Sprite Size Trigger",
            data = {
                width = 8,
                height = 8,
                Scale = "1,1",
                Flag = "",
                Persistent = false
            },
        },
    },
}

return PlayerSpriteSizeTrigger